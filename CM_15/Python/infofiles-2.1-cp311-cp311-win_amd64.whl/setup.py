"""A setup script to package pre-built Python modules."""

import os
import shutil

from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext


# check if environment variables are set
package_name = os.environ.get("MODULENAME")
if not package_name:
    raise ValueError("MODULENAME not set.")

package_path = os.environ.get("MODULEPATH")
if not package_path:
    raise ValueError("MODULEPATH not set.")

package_version = os.environ.get("MODULEVERSION")
if not package_version:
    raise ValueError("MODULEVERSION not set.")

python_version = os.environ.get("PY_VER")
if not python_version:
    raise ValueError("PY_VER not set.")

limited_api = os.environ.get("LIMITED_API", "0")    # default to "0" if not set
limited_api = bool(int(limited_api))                # Convert to True/False

python_version = f'>={python_version}'

def find_source_files(path, extensions=(".py", ".so", ".pyd")):
    if limited_api:
        path = f'{path}/{package_name}'
    matches = []
    for dirpath, _, filenames in os.walk(path):
        for filename in filenames:
            if filename.endswith(extensions):
                matches.append(os.path.join(dirpath, filename))
    return matches

sources = find_source_files(package_path)

class PackPreBuilt(build_ext):
    def run(self):
        build_lib = self.build_lib
        if limited_api:
            build_lib = os.path.join(build_lib, package_name)
        os.makedirs(build_lib, exist_ok=True)
        for source in sources:
            dst = os.path.join(build_lib, os.path.basename(source))
            print(f"Copying {source} -> {dst}")
            shutil.copyfile(source, dst)

if limited_api:
    setup(
        name=package_name,
        version=package_version,
        packages=[package_name],
        package_dir={package_name: package_name},
        ext_modules=[
            Extension(  # dummy C extension,
                f"{package_name}.{os.path.basename(module)}",
                sources=[],
                py_limited_api=limited_api,
            )
            for module in sources
        ],
        cmdclass={"build_ext": PackPreBuilt},
        # install_requires=
        # [
        #     'apoc==2.3.3',
        #     'infofiles==2.0.3'
        # ],

    )
else:
    setup(
        name=package_name,
        version=package_version,
        ext_modules=[
            Extension(  # dummy C extension,
                package_name,
                sources=[],
                py_limited_api=limited_api,
            )
        ],
        python_requires=python_version,
        cmdclass={"build_ext": PackPreBuilt},
    )
